"""BCS 306 University Registration System.

A Tkinter desktop client for the supplied MySQL 8 university project.
Requires: pip install mysql-connector-python
"""

import tkinter as tk
from tkinter import ttk, messagebox
import mysql.connector

DB_NAME = "bcs306_university"

COLORS = {
    "nav": "#101A2E",
    "nav_alt": "#1C2A43",
    "blue": "#2563EB",
    "blue_light": "#EAF1FF",
    "cyan": "#38BDF8",
    "background": "#F3F6FC",
    "white": "#FFFFFF",
    "border": "#DBE4F0",
    "text": "#17263D",
    "muted": "#667992",
    "green": "#047857",
    "red": "#B91C1C",
}


class UniversityApp:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("NEXUS | University Registration")
        self.root.geometry("1280x780")
        self.root.minsize(1000, 650)
        self.root.configure(bg=COLORS["background"])
        self.conn = None
        self.user = ""
        self.role = ""
        self.active_page = ""
        self.nav_buttons = {}
        self.configure_style()
        self.login_screen()

    def configure_style(self):
        style = ttk.Style(self.root)
        style.theme_use("clam")
        style.configure("Data.Treeview", font=("Segoe UI", 10), rowheight=35,
                        background=COLORS["white"], fieldbackground=COLORS["white"],
                        foreground=COLORS["text"], borderwidth=0)
        style.configure("Data.Treeview.Heading", font=("Segoe UI Semibold", 10),
                        background="#E8EEF7", foreground=COLORS["text"],
                        padding=(12, 11), relief="flat")
        style.map("Data.Treeview", background=[("selected", COLORS["blue_light"])],
                  foreground=[("selected", COLORS["text"])])
        style.map("Data.Treeview.Heading", background=[("active", "#DFE8F6")])
        style.configure("Styled.TCombobox", font=("Segoe UI", 10), padding=7)

    def clear(self):
        for child in self.root.winfo_children():
            child.destroy()

    def label(self, parent, text, size=10, color=None, bold=False, bg=None):
        return tk.Label(parent, text=text, bg=bg or parent.cget("bg"),
                        fg=color or COLORS["text"],
                        font=("Segoe UI Semibold" if bold else "Segoe UI", size),
                        anchor="w")

    def button(self, parent, text, command, primary=True, width=None):
        return tk.Button(parent, text=text, command=command, cursor="hand2",
                         font=("Segoe UI Semibold", 10),
                         fg=COLORS["white"] if primary else COLORS["blue"],
                         bg=COLORS["blue"] if primary else COLORS["blue_light"],
                         activeforeground=COLORS["white"] if primary else COLORS["blue"],
                         activebackground="#1D4ED8" if primary else "#DCE8FF",
                         borderwidth=0, relief="flat", padx=17, pady=10,
                         width=width)

    def entry(self, parent, variable, width=18, password=False):
        return tk.Entry(parent, textvariable=variable,
                        show="*" if password else "", width=width,
                        relief="solid", borderwidth=1,
                        highlightbackground=COLORS["border"],
                        highlightcolor=COLORS["blue"], highlightthickness=1,
                        bg=COLORS["white"], fg=COLORS["text"],
                        insertbackground=COLORS["blue"],
                        font=("Segoe UI", 10))

    def form_field(self, parent, title, default="", width=18, password=False):
        cell = tk.Frame(parent, bg=COLORS["white"])
        self.label(cell, title, size=9, color=COLORS["muted"], bold=True).pack(
            anchor="w", pady=(0, 5))
        variable = tk.StringVar(value=default)
        widget = self.entry(cell, variable, width=width, password=password)
        widget.pack(fill="x", ipady=9)
        return cell, variable, widget

    def card(self, parent, padding=18):
        outer = tk.Frame(parent, bg=COLORS["white"],
                         highlightbackground=COLORS["border"], highlightthickness=1)
        inner = tk.Frame(outer, bg=COLORS["white"], padx=padding, pady=padding)
        inner.pack(fill="both", expand=True)
        return outer, inner

    def login_screen(self):
        self.clear()
        self.root.configure(bg=COLORS["background"])
        layout = tk.Frame(self.root, bg=COLORS["white"])
        layout.pack(fill="both", expand=True)
        left = tk.Frame(layout, bg=COLORS["nav"], width=460)
        left.pack(side="left", fill="y")
        left.pack_propagate(False)
        tk.Label(left, text="N  /  NEXUS", bg=COLORS["nav"], fg=COLORS["cyan"],
                 font=("Segoe UI Semibold", 17)).pack(anchor="w", padx=55, pady=(72, 0))
        tk.Frame(left, bg=COLORS["cyan"], width=55, height=5).pack(
            anchor="w", padx=55, pady=(90, 28))
        tk.Label(left, text="One system.\nEvery academic\nrecord.",
                 bg=COLORS["nav"], fg=COLORS["white"], justify="left",
                 font=("Segoe UI Semibold", 32)).pack(anchor="w", padx=55)
        tk.Label(left, text="Student records, registration, grades,\nand reporting in one workspace.",
                 bg=COLORS["nav"], fg="#ADBED5", justify="left",
                 font=("Segoe UI", 12)).pack(anchor="w", padx=55, pady=(23, 0))
        tk.Label(left, text="BCS 306  |  UNIVERSITY PROJECT", bg=COLORS["nav"],
                 fg="#90A9CD", font=("Segoe UI Semibold", 9)).pack(
                     side="bottom", anchor="w", padx=55, pady=44)

        right = tk.Frame(layout, bg=COLORS["white"])
        right.pack(side="left", fill="both", expand=True)
        login = tk.Frame(right, bg=COLORS["white"], width=425)
        login.place(relx=0.5, rely=0.49, anchor="center")
        self.label(login, "Welcome back", 28, bold=True).pack(anchor="w")
        self.label(login, "Sign in with your assigned MySQL account.", 11,
                   color=COLORS["muted"]).pack(anchor="w", pady=(8, 28))
        host_f, self.host, _ = self.form_field(login, "DATABASE HOST", "localhost", 35)
        host_f.pack(fill="x", pady=(0, 14))
        user_f, self.username, _ = self.form_field(login, "MYSQL USERNAME", "uni_registrar", 35)
        user_f.pack(fill="x", pady=(0, 14))
        pass_f, self.password, pw = self.form_field(login, "PASSWORD", "", 35, password=True)
        pass_f.pack(fill="x", pady=(0, 22))
        self.button(login, "Sign in to dashboard", self.login).pack(fill="x")
        self.label(login, "Your database account controls access to each feature.", 9,
                   color=COLORS["muted"]).pack(anchor="w", pady=(21, 0))
        self.root.bind("<Return>", lambda _event: self.login())
        pw.focus_set()

    def login(self):
        if self.conn:
            try:
                self.conn.close()
            except mysql.connector.Error:
                pass
            self.conn = None
        try:
            self.conn = mysql.connector.connect(
                host=self.host.get().strip(), user=self.username.get().strip(),
                password=self.password.get(), database=DB_NAME,
                connection_timeout=6)
            self.user = self.username.get().strip()
            self.role = {"uni_registrar": "registrar", "uni_officer": "officer",
                         "uni_report": "report"}.get(self.user, "limited")
            self.root.unbind("<Return>")
            self.main_screen()
        except mysql.connector.Error as exc:
            messagebox.showerror("Unable to sign in", str(exc))

    def logout(self):
        if self.conn:
            try:
                self.conn.close()
            except mysql.connector.Error:
                pass
            self.conn = None
        self.login_screen()

    def execute(self, query, params=(), fetch=False, procedure=False):
        if not self.conn or not self.conn.is_connected():
            raise mysql.connector.Error("The MySQL connection is unavailable.")
        cursor = self.conn.cursor()
        try:
            if procedure:
                cursor.callproc(query, params)
                result = None
                for stored in cursor.stored_results():
                    result = (stored.column_names, stored.fetchall())
                self.conn.commit()
                return result
            cursor.execute(query, params)
            if fetch:
                result = (cursor.column_names, cursor.fetchall())
                return result
            self.conn.commit()
            return cursor.rowcount
        except mysql.connector.Error:
            self.conn.rollback()
            raise
        finally:
            cursor.close()

    def notify(self, fn, message):
        try:
            fn()
            messagebox.showinfo("Operation complete", message)
        except (mysql.connector.Error, ValueError) as exc:
            messagebox.showerror("Operation rejected", str(exc))

    def main_screen(self):
        self.clear()
        self.root.configure(bg=COLORS["background"])
        shell = tk.Frame(self.root, bg=COLORS["background"])
        shell.pack(fill="both", expand=True)

        self.sidebar = tk.Frame(shell, bg=COLORS["nav"], width=235)
        self.sidebar.pack(side="left", fill="y")
        self.sidebar.pack_propagate(False)
        tk.Label(self.sidebar, text="N  /  NEXUS", bg=COLORS["nav"],
                 fg=COLORS["cyan"], font=("Segoe UI Semibold", 17)).pack(
                     anchor="w", padx=24, pady=(29, 5))
        tk.Label(self.sidebar, text="UNIVERSITY MANAGEMENT", bg=COLORS["nav"],
                 fg="#94A9C5", font=("Segoe UI Semibold", 8)).pack(
                     anchor="w", padx=24, pady=(0, 32))
        self.pages = {"Dashboard": self.dashboard_page, "Registrations": self.registrations_page,
                      "Sections": self.sections_page, "Reports": self.reports_page}
        if self.role in ("registrar", "officer"):
            self.pages = {"Dashboard": self.dashboard_page, "Students": self.students_page,
                          **{k: v for k, v in self.pages.items() if k != "Dashboard"}}
        if self.role == "registrar":
            self.pages["Audit history"] = self.audit_page
        for name in self.pages:
            self.nav_buttons[name] = tk.Button(
                self.sidebar, text="   " + name, anchor="w", cursor="hand2",
                bg=COLORS["nav"], fg="#C2D0E4", relief="flat", bd=0,
                activebackground=COLORS["nav_alt"], activeforeground=COLORS["white"],
                font=("Segoe UI Semibold", 11), pady=13, padx=18,
                highlightthickness=0,
                command=lambda page=name: self.go(page))
            self.nav_buttons[name].pack(fill="x", padx=12, pady=3)
        tk.Label(self.sidebar, text=f"SIGNED IN AS\n{self.user}", justify="left",
                 bg=COLORS["nav"], fg="#B0C2DC",
                 font=("Segoe UI", 10)).pack(side="bottom", anchor="w",
                                            padx=24, pady=28)

        area = tk.Frame(shell, bg=COLORS["background"])
        area.pack(side="left", fill="both", expand=True)
        topbar = tk.Frame(area, bg=COLORS["white"], height=70,
                          highlightbackground=COLORS["border"], highlightthickness=1)
        topbar.pack(fill="x")
        topbar.pack_propagate(False)
        self.page_title = tk.Label(topbar, bg=COLORS["white"], fg=COLORS["text"],
                                   font=("Segoe UI Semibold", 17))
        self.page_title.pack(side="left", padx=28)
        self.button(topbar, "Log out", self.logout, primary=False).pack(
            side="right", padx=25, pady=14)
        self.label(topbar, self.role.upper(), 9, COLORS["muted"], True,
                   COLORS["white"]).pack(side="right", padx=(0, 15))
        self.content = tk.Frame(area, bg=COLORS["background"], padx=25, pady=24)
        self.content.pack(fill="both", expand=True)
        self.go("Dashboard")

    def go(self, name):
        self.active_page = name
        for title, button in self.nav_buttons.items():
            selected = title == name
            button.config(bg=COLORS["blue"] if selected else COLORS["nav"],
                          fg=COLORS["white"] if selected else "#C2D0E4")
        self.page_title.config(text=name)
        for child in self.content.winfo_children():
            child.destroy()
        self.pages[name](self.content)

    def section_header(self, parent, title, subtitle):
        header = tk.Frame(parent, bg=COLORS["background"])
        header.pack(fill="x", pady=(0, 20))
        self.label(header, title, size=21, bold=True,
                   bg=COLORS["background"]).pack(anchor="w")
        self.label(header, subtitle, size=10, color=COLORS["muted"],
                   bg=COLORS["background"]).pack(anchor="w", pady=(4, 0))

    def stat_tile(self, parent, label, value, foot):
        tile, inside = self.card(parent, padding=17)
        tile.pack(side="left", fill="both", expand=True, padx=(0, 13))
        self.label(inside, label, size=10, color=COLORS["muted"]).pack(anchor="w")
        self.label(inside, value, size=27, bold=True).pack(anchor="w", pady=(6, 3))
        self.label(inside, foot, size=9, color=COLORS["muted"]).pack(anchor="w")

    def dashboard_page(self, parent):
        self.section_header(parent, "Academic overview",
                            "Live data from your university registration database")
        stats = tk.Frame(parent, bg=COLORS["background"])
        stats.pack(fill="x")
        try:
            _, rows = self.execute("SELECT MaximumCapacity, ActiveEnrollment, RemainingSeats "
                                   "FROM SectionCapacity", fetch=True)
            sections = len(rows)
            enrolled = sum(int(r[1]) for r in rows)
            remaining = sum(int(r[2]) for r in rows)
            _, registrations = self.execute("SELECT RegistrationID FROM RegistrationDetails",
                                            fetch=True)
            reg_count = len(registrations)
            self.stat_tile(stats, "COURSE SECTIONS", str(sections), "Current offerings")
            self.stat_tile(stats, "ACTIVE ENROLLMENT", str(enrolled), "Registered status")
            self.stat_tile(stats, "AVAILABLE SEATS", str(remaining), "Across all sections")
            self.stat_tile(stats, "REGISTRATIONS", str(reg_count), "All statuses")
        except mysql.connector.Error as exc:
            self.label(parent, "Dashboard data unavailable: " + str(exc), size=10,
                       color=COLORS["red"], bg=COLORS["background"]).pack(anchor="w", pady=14)
        outer, info = self.card(parent, padding=25)
        outer.pack(fill="x", pady=(23, 0))
        self.label(info, "Quick access", size=17, bold=True).pack(anchor="w")
        self.label(info, "Choose a workspace to review or manage academic records.",
                   color=COLORS["muted"]).pack(anchor="w", pady=(6, 22))
        shortcuts = tk.Frame(info, bg=COLORS["white"])
        shortcuts.pack(anchor="w")
        for name in ("Students", "Registrations", "Sections", "Reports"):
            if name in self.pages:
                self.button(shortcuts, name, lambda page=name: self.go(page),
                            primary=False).pack(side="left", padx=(0, 12))

    def build_table(self, parent):
        frame = tk.Frame(parent, bg=COLORS["white"])
        frame.pack(fill="both", expand=True)
        tree = ttk.Treeview(frame, style="Data.Treeview", show="headings", selectmode="browse")
        vertical = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
        horizontal = ttk.Scrollbar(frame, orient="horizontal", command=tree.xview)
        tree.configure(yscrollcommand=vertical.set, xscrollcommand=horizontal.set)
        tree.grid(row=0, column=0, sticky="nsew")
        vertical.grid(row=0, column=1, sticky="ns")
        horizontal.grid(row=1, column=0, sticky="ew")
        frame.columnconfigure(0, weight=1)
        frame.rowconfigure(0, weight=1)
        tree.tag_configure("even", background=COLORS["white"])
        tree.tag_configure("odd", background="#F5F8FD")
        return tree

    def display(self, tree, data):
        if data is None:
            return
        names, rows = data
        tree.delete(*tree.get_children())
        tree["columns"] = list(names)
        for name in names:
            tree.heading(name, text=name)
            tree.column(name, anchor="w", minwidth=105, width=165, stretch=True)
        for index, record in enumerate(rows):
            tree.insert("", "end", tags=("even" if index % 2 == 0 else "odd",),
                        values=["" if cell is None else str(cell) for cell in record])

    def refresh(self, tree, sql, args=()):
        try:
            self.display(tree, self.execute(sql, args, fetch=True))
        except mysql.connector.Error as exc:
            messagebox.showerror("Unable to load records", str(exc))

    def table_card(self, parent, title):
        outer, body = self.card(parent, padding=14)
        outer.pack(fill="both", expand=True)
        self.label(body, title, size=13, bold=True).pack(anchor="w", pady=(0, 12))
        return self.build_table(body)

    def students_page(self, parent):
        self.section_header(parent, "Student directory", "Search records and register new students")
        form_outer, form = self.card(parent, 16)
        form_outer.pack(fill="x", pady=(0, 16))
        self.label(form, "New student", size=13, bold=True).pack(anchor="w", pady=(0, 11))
        row = tk.Frame(form, bg=COLORS["white"])
        row.pack(fill="x")
        fields = {}
        specs = [("Student ID", "", 9), ("First name", "", 12),
                 ("Family name", "", 12), ("Date of birth", "YYYY-MM-DD", 13),
                 ("Email", "", 25), ("Admission year", "2026", 10),
                 ("Department", "CS", 9)]
        for title, default, width in specs:
            box, var, _ = self.form_field(row, title, default, width)
            box.pack(side="left", padx=(0, 9))
            fields[title] = var
        def add_student():
            def operation():
                get = lambda key: fields[key].get().strip()
                self.execute("""INSERT INTO Student
                    (StudentID,FirstName,FamilyName,DateOfBirth,Email,
                     AdmissionYear,AcademicStatus,DeptCode)
                    VALUES (%s,%s,%s,%s,%s,%s,'Active',%s)""",
                    (int(get("Student ID")), get("First name"), get("Family name"),
                     get("Date of birth"), get("Email"), int(get("Admission year")),
                     get("Department")))
                self.refresh(tree, sql)
            self.notify(operation, "Student added to the database")
        self.button(form, "+ Add student", add_student).pack(anchor="w", pady=(15, 0))

        search_row = tk.Frame(parent, bg=COLORS["background"])
        search_row.pack(fill="x", pady=(0, 12))
        self.label(search_row, "Student ID", color=COLORS["muted"],
                   bg=COLORS["background"]).pack(side="left")
        student_id = tk.StringVar()
        self.entry(search_row, student_id, 12).pack(side="left", ipady=8, padx=8)
        sql = ("SELECT StudentID, FirstName, MiddleName, FamilyName, DateOfBirth, "
               "TIMESTAMPDIFF(YEAR,DateOfBirth,CURDATE()) AS Age, "
               "Email, AcademicStatus, DeptCode, AdvisorID FROM Student")
        self.button(search_row, "Search", lambda: self.search_student(
            tree, sql, student_id.get()), primary=False).pack(side="left")
        self.button(search_row, "Show all", lambda: self.refresh(
            tree, sql + " ORDER BY StudentID"), primary=False).pack(side="left", padx=8)
        tree = self.table_card(parent, "Student records")
        self.refresh(tree, sql + " ORDER BY StudentID")

    def search_student(self, tree, sql, raw_id):
        if not raw_id.strip():
            self.refresh(tree, sql + " ORDER BY StudentID")
            return
        try:
            student_id = int(raw_id.strip())
        except ValueError:
            messagebox.showerror("Search error", "Enter a numeric student ID")
            return
        self.refresh(tree, sql + " WHERE StudentID=%s ORDER BY StudentID", (student_id,))

    def sections_page(self, parent):
        self.section_header(parent, "Section capacity",
                            "Track active registration and remaining available seats")
        toolbar = tk.Frame(parent, bg=COLORS["background"])
        toolbar.pack(fill="x", pady=(0, 12))
        sql = "SELECT * FROM SectionCapacity ORDER BY AcademicYear, Semester, CourseCode, SectionNo"
        self.button(toolbar, "Refresh capacity", lambda: self.refresh(tree, sql)).pack(side="right")
        tree = self.table_card(parent, "All course sections")
        self.refresh(tree, sql)

    def registrations_page(self, parent):
        self.section_header(parent, "Registration center",
                            "Enroll students, change status, and record grades")
        sql = "SELECT * FROM RegistrationDetails ORDER BY RegistrationID"
        if self.role in ("registrar", "officer"):
            outer, form = self.card(parent, 14)
            outer.pack(fill="x", pady=(0, 14))
            self.label(form, "Register a student", size=13, bold=True).pack(anchor="w", pady=(0, 12))
            row = tk.Frame(form, bg=COLORS["white"])
            row.pack(fill="x")
            fields = {}
            for name, default, width in [("Student ID", "", 10), ("Course code", "BCS306", 12),
                                         ("Section", "01", 9), ("Semester", "Fall", 11),
                                         ("Year", "2026", 9)]:
                cell, var, _ = self.form_field(row, name, default, width)
                cell.pack(side="left", padx=(0, 13))
                fields[name] = var
            def register():
                def operation():
                    self.execute("RegisterStudent", (
                        int(fields["Student ID"].get()), fields["Course code"].get().strip(),
                        fields["Section"].get().strip(), fields["Semester"].get().strip(),
                        int(fields["Year"].get())), procedure=True)
                    self.refresh(tree, sql)
                self.notify(operation, "Student registered")
            self.button(form, "+ Create registration", register).pack(anchor="w", pady=(13, 0))

            outer2, edit = self.card(parent, 14)
            outer2.pack(fill="x", pady=(0, 14))
            self.label(edit, "Update registration", size=13, bold=True).pack(anchor="w", pady=(0, 12))
            row2 = tk.Frame(edit, bg=COLORS["white"])
            row2.pack(fill="x")
            id_cell, reg_id, _ = self.form_field(row2, "Registration ID", "", 13)
            id_cell.pack(side="left", padx=(0, 12))
            status_cell = tk.Frame(row2, bg=COLORS["white"])
            status_cell.pack(side="left", padx=(0, 12))
            self.label(status_cell, "Registration status", 9, COLORS["muted"], True).pack(anchor="w", pady=(0, 5))
            status = tk.StringVar(value="Dropped")
            ttk.Combobox(status_cell, textvariable=status, style="Styled.TCombobox",
                         values=["Registered", "Dropped", "Completed"],
                         state="readonly", width=15).pack()
            def change_status():
                def operation():
                    self.execute("ChangeRegistrationStatus", (int(reg_id.get()), status.get()),
                                 procedure=True)
                    self.refresh(tree, sql)
                self.notify(operation, "Registration status updated")
            self.button(row2, "Save status", change_status, primary=False).pack(
                side="left", padx=(4, 18), pady=(19, 0))
            if self.role == "registrar":
                mark_cell, mark, _ = self.form_field(row2, "Final mark (0-100)", "", 12)
                mark_cell.pack(side="left", padx=(0, 10))
                def save_mark():
                    def operation():
                        self.execute("SetFinalMark", (int(reg_id.get()), float(mark.get())),
                                     procedure=True)
                        self.refresh(tree, sql)
                    self.notify(operation, "Final mark saved and audited")
                self.button(row2, "Save mark", save_mark).pack(side="left", pady=(19, 0))
        toolbar = tk.Frame(parent, bg=COLORS["background"])
        toolbar.pack(fill="x", pady=(0, 10))
        self.button(toolbar, "Refresh registrations", lambda: self.refresh(tree, sql),
                    primary=False).pack(side="right")
        tree = self.table_card(parent, "Enrollment records")
        self.refresh(tree, sql)

    def reports_page(self, parent):
        self.section_header(parent, "Reports & analytics",
                            "Academic Section Performance and Capacity Report")
        outer, controls = self.card(parent, 18)
        outer.pack(fill="x", pady=(0, 15))
        left = tk.Frame(controls, bg=COLORS["white"])
        left.pack(side="left")
        semester_cell = tk.Frame(left, bg=COLORS["white"])
        semester_cell.pack(side="left", padx=(0, 15))
        self.label(semester_cell, "SEMESTER", 9, COLORS["muted"], True).pack(anchor="w", pady=(0, 7))
        semester = tk.StringVar(value="Fall")
        ttk.Combobox(semester_cell, textvariable=semester,
                     values=["Fall", "Spring", "Summer"], state="readonly", width=13).pack()
        year_cell, year, _ = self.form_field(left, "ACADEMIC YEAR", "2026", 12)
        year_cell.pack(side="left", padx=(0, 15))
        def load_report():
            try:
                self.display(tree, self.execute("AcademicSectionReport",
                                                (semester.get(), int(year.get())), procedure=True))
            except (mysql.connector.Error, ValueError) as exc:
                messagebox.showerror("Report error", str(exc))
        self.button(controls, "Generate report", load_report).pack(side="right", pady=13)
        shortcuts = tk.Frame(parent, bg=COLORS["background"])
        shortcuts.pack(fill="x", pady=(0, 12))
        self.button(shortcuts, "Registration list", lambda: self.refresh(
            tree, "SELECT * FROM RegistrationDetails"), primary=False).pack(side="left", padx=(0, 9))
        self.button(shortcuts, "Section capacity", lambda: self.refresh(
            tree, "SELECT * FROM SectionCapacity"), primary=False).pack(side="left")
        tree = self.table_card(parent, "Report results")

    def audit_page(self, parent):
        self.section_header(parent, "Audit history",
                            "Database-generated events for registration changes")
        toolbar = tk.Frame(parent, bg=COLORS["background"])
        toolbar.pack(fill="x", pady=(0, 12))
        sql = "SELECT * FROM RegistrationAudit ORDER BY AuditID DESC"
        self.button(toolbar, "Refresh audit history", lambda: self.refresh(tree, sql)).pack(
            side="right")
        tree = self.table_card(parent, "Registration audit events")
        self.refresh(tree, sql)


def main():
    UniversityApp().root.mainloop()


if __name__ == "__main__":
    main()