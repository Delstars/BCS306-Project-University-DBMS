# BCS 306 Project 1: University Registration System

## Files
- 01_University_Database.sql: complete MySQL 8 database schema, dummy data, transactions, views, procedures, audit triggers, report and demo roles
- 02_University_GUI.py: Python Tkinter desktop app, MySQL username/password login
- 03_University_ERD.drawio: editable ER diagram (open via app.diagrams.net)
- 03_University_ERD.mmd: Mermaid diagram source
- 04_Relational_Schema_3NF.docx: full relational schema and normalization explanation
- 05_Technical_Report_Draft.docx: written project report draft, pending screenshots and verified outputs
- 06_Test_Checklist.sql: safe SELECT checks and optional manual negative tests
- requirements.txt: GUI dependency
- Run_GUI.bat: launch GUI
- .vscode/launch.json: VS Code Run/Debug configuration

## How to run in VS Code
1. Open this folder in VS Code.
2. Install the VS Code Python extension if prompted.
3. Open 02_University_GUI.py and select the Python 3.13 interpreter.
4. Press F5 and choose BCS306 University GUI.
5. The app opens a MySQL login window. Use YOUR valid MySQL username/password for this database.

Python and mysql-connector-python are installed on this PC.

## MySQL setup
1. Open MySQL Workbench using an administrative MySQL connection.
2. If bcs306_university already exists, do NOT run the entire SQL setup because the first statement drops the database.
3. If no database exists, open 01_University_Database.sql and execute it once, after checking the warnings and sample accounts.
4. Refresh the SCHEMAS section, then confirm all 10 tables, two views, four procedures and audit triggers exist.
5. Log into the app with an account created by the script. Change the demonstration account passwords before any real use.

## Roles
- uni_registrar: operations and mark updates, reports, audit
- uni_officer: student and registration operations
- uni_report: approved views and performance report only

## What has and has not been tested
- Python syntax, Tkinter availability and mysql-connector import: local checks
- Live MySQL login, SQL schema creation and GUI/database integration: not yet verified because the MySQL admin connection requires your password
- The technical report includes placeholders for screenshots, negative-case evidence, and query outputs. Replace only after running live demonstrations.

## Project brief vs course syllabus
Kept MySQL table definitions, constraints, INSERT, SELECT, JOIN, GROUP BY, HAVING, aggregate functions, subqueries, views, basic transactions and privileges.
Four procedures and audit/validation triggers are additionally included because the Project 1 assignment explicitly requires them.
No web service, framework, ORM, Docker or cloud database is used.

## Known design limitation
MySQL does not defer foreign-key checks. The Department chair / Instructor membership relationship is circular; the supplied SQL inserts departments and instructors in two passes before adding the chair FK. Adding new departments later needs a controlled staging procedure or schema adjustment. Document this decision in Task 4.
