@echo off
cd /d "%~dp0"
py 02_University_GUI.py
if errorlevel 1 pause
