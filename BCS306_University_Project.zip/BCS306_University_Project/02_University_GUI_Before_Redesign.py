"""BCS 306 Project 1 desktop GUI. Requires: pip install mysql-connector-python"""
import tkinter as tk
from tkinter import ttk, messagebox
import mysql.connector

DB = 'bcs306_university'

class UniversityApp:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title('BCS 306 | University Registration')
        self.root.geometry('1100x700')
        self.root.minsize(900, 560)
        self.conn = None
        self.user = ''
        self.role = ''
        self.login_screen()

    def clear(self):
        for widget in self.root.winfo_children():
            widget.destroy()

    def field(self, parent, title, row, initial='', password=False):
        ttk.Label(parent, text=title).grid(row=row, column=0, sticky='w', padx=8, pady=5)
        var = tk.StringVar(value=initial)
        ttk.Entry(parent, textvariable=var, width=32, show='*' if password else '').grid(
            row=row, column=1, sticky='ew', padx=8, pady=5)
        return var

    def login_screen(self):
        self.clear()
        box = ttk.Frame(self.root, padding=28)
        box.pack(expand=True)
        ttk.Label(box, text='University Registration System', font=('Segoe UI', 20, 'bold')).grid(
            row=0, column=0, columnspan=2, pady=16)
        self.host = self.field(box, 'MySQL host', 1, 'localhost')
        self.username = self.field(box, 'MySQL username', 2, 'uni_registrar')
        self.password = self.field(box, 'Password', 3, password=True)
        ttk.Button(box, text='Log in', command=self.login).grid(row=4, column=0, columnspan=2, pady=20)
        ttk.Label(box, text='Use a MySQL account created by your database script.').grid(
            row=5, column=0, columnspan=2)
        self.root.bind('<Return>', lambda event: self.login())

    def login(self):
        if self.conn:
            try: self.conn.close()
            except mysql.connector.Error: pass
        try:
            self.conn = mysql.connector.connect(host=self.host.get().strip(),
                user=self.username.get().strip(), password=self.password.get(), database=DB,
                connection_timeout=6)
            self.user = self.username.get().strip()
            self.role = {'uni_registrar':'registrar', 'uni_officer':'officer',
                         'uni_report':'report'}.get(self.user, 'limited')
            self.root.unbind('<Return>')
            self.main_screen()
        except mysql.connector.Error as exc:
            messagebox.showerror('Login failed', str(exc))

    def execute(self, query, params=(), fetch=False, procedure=False):
        cursor = self.conn.cursor()
        try:
            if procedure:
                cursor.callproc(query, params)
                results = []
                for result in cursor.stored_results():
                    results = (result.column_names, result.fetchall())
                self.conn.commit()
                return results
            cursor.execute(query, params)
            if fetch:
                return (cursor.column_names, cursor.fetchall())
            self.conn.commit()
            return cursor.rowcount
        except mysql.connector.Error:
            self.conn.rollback()
            raise
        finally:
            cursor.close()

    def run(self, operation, success='Operation completed'):
        try:
            result = operation()
            messagebox.showinfo('Success', success)
            return result
        except (mysql.connector.Error, ValueError) as exc:
            messagebox.showerror('Database error', str(exc))
            return None

    def query_table(self, parent):
        frame = ttk.Frame(parent)
        frame.pack(fill='both', expand=True, padx=12, pady=8)
        tree = ttk.Treeview(frame, show='headings')
        yscroll = ttk.Scrollbar(frame, orient='vertical', command=tree.yview)
        xscroll = ttk.Scrollbar(frame, orient='horizontal', command=tree.xview)
        tree.configure(yscrollcommand=yscroll.set, xscrollcommand=xscroll.set)
        tree.grid(row=0, column=0, sticky='nsew')
        yscroll.grid(row=0, column=1, sticky='ns')
        xscroll.grid(row=1, column=0, sticky='ew')
        frame.columnconfigure(0, weight=1)
        frame.rowconfigure(0, weight=1)
        return tree

    def display(self, tree, result):
        if not result:
            return
        columns, records = result
        tree.delete(*tree.get_children())
        tree['columns'] = list(columns)
        for heading in columns:
            tree.heading(heading, text=heading)
            tree.column(heading, width=150, minwidth=95, stretch=True)
        for record in records:
            tree.insert('', 'end', values=[('' if x is None else str(x)) for x in record])

    def refresh(self, tree, sql, params=()):
        try:
            self.display(tree, self.execute(sql, params, fetch=True))
        except mysql.connector.Error as exc:
            messagebox.showerror('Database error', str(exc))

    def main_screen(self):
        self.clear()
        header = ttk.Frame(self.root, padding=12)
        header.pack(fill='x')
        ttk.Label(header, text='University Registration', font=('Segoe UI', 17, 'bold')).pack(side='left')
        ttk.Button(header, text='Log out', command=self.login_screen).pack(side='right', padx=6)
        ttk.Label(header, text=f'{self.user} | {self.role}').pack(side='right', padx=10)
        tabs = ttk.Notebook(self.root)
        tabs.pack(fill='both', expand=True)
        pages = [('Registrations', self.registrations_tab), ('Sections', self.sections_tab),
                 ('Reports', self.reports_tab)]
        if self.role in ('registrar', 'officer'):
            pages.insert(0, ('Students', self.students_tab))
        for title, builder in pages:
            tab = ttk.Frame(tabs)
            tabs.add(tab, text=title)
            builder(tab)
        if self.role == 'registrar':
            tab = ttk.Frame(tabs)
            tabs.add(tab, text='Audit history')
            self.audit_tab(tab)

    def students_tab(self, tab):
        tree = self.query_table(tab)
        sql = '''SELECT StudentID, FirstName, MiddleName, FamilyName, DateOfBirth,
                 TIMESTAMPDIFF(YEAR,DateOfBirth,CURDATE()) Age, Email, AcademicStatus,
                 DeptCode, AdvisorID FROM Student ORDER BY StudentID'''
        controls = ttk.Frame(tab, padding=8)
        controls.pack(fill='x')
        if self.role in ('registrar','officer'):
            ttk.Label(controls, text='Add student').pack(side='left', padx=5)
            fields = {}
            for key, width in [('ID',7),('First',11),('Family',11),('DOB YYYY-MM-DD',16),
                               ('Email',23),('Year',7),('Dept',7)]:
                ttk.Label(controls, text=key).pack(side='left', padx=2)
                variable = tk.StringVar()
                ttk.Entry(controls, textvariable=variable, width=width).pack(side='left', padx=2)
                fields[key] = variable
            def add_student():
                def action():
                    f = lambda key: fields[key].get().strip()
                    self.execute('''INSERT INTO Student (StudentID,FirstName,FamilyName,DateOfBirth,
                        Email,AdmissionYear,AcademicStatus,DeptCode) VALUES (%s,%s,%s,%s,%s,%s,'Active',%s)''',
                        (int(f('ID')),f('First'),f('Family'),f('DOB YYYY-MM-DD'),f('Email'),
                         int(f('Year')),f('Dept')))
                    self.refresh(tree, sql)
                self.run(action, 'Student added')
            ttk.Button(controls, text='Add', command=add_student).pack(side='left', padx=6)
        ttk.Button(controls, text='Refresh', command=lambda:self.refresh(tree,sql)).pack(side='right')
        self.refresh(tree, sql)

    def sections_tab(self, tab):
        tree = self.query_table(tab)
        sql = 'SELECT * FROM SectionCapacity ORDER BY AcademicYear, Semester, CourseCode, SectionNo'
        ttk.Button(tab, text='Refresh capacity', command=lambda:self.refresh(tree,sql)).pack(anchor='e', padx=12, pady=5)
        self.refresh(tree, sql)

    def registrations_tab(self, tab):
        tree = self.query_table(tab)
        sql = 'SELECT * FROM RegistrationDetails ORDER BY RegistrationID'
        toolbar = ttk.Frame(tab, padding=8)
        toolbar.pack(fill='x')
        ttk.Button(toolbar, text='Refresh', command=lambda:self.refresh(tree,sql)).pack(side='right', padx=6)
        if self.role in ('registrar','officer'):
            form = ttk.LabelFrame(tab, text='Register a student', padding=8)
            form.pack(fill='x', padx=12, pady=5)
            variables = {}
            for i, (label, default) in enumerate([('Student ID',''),('Course','BCS306'),
                 ('Section','01'),('Semester','Fall'),('Year','2026')]):
                ttk.Label(form, text=label).grid(row=0,column=i*2,padx=3)
                var = tk.StringVar(value=default)
                ttk.Entry(form,textvariable=var,width=13).grid(row=0,column=i*2+1,padx=3)
                variables[label] = var
            def register():
                def action():
                    v = lambda key:variables[key].get().strip()
                    self.execute('RegisterStudent',(int(v('Student ID')),v('Course'),v('Section'),
                        v('Semester'),int(v('Year'))),procedure=True)
                    self.refresh(tree,sql)
                self.run(action, 'Registration created')
            ttk.Button(form,text='Register',command=register).grid(row=0,column=10,padx=12)
            actions = ttk.LabelFrame(tab,text='Update registration',padding=8)
            actions.pack(fill='x',padx=12,pady=5)
            ttk.Label(actions,text='Registration ID').pack(side='left')
            reg_id = tk.StringVar()
            ttk.Entry(actions,textvariable=reg_id,width=10).pack(side='left',padx=6)
            ttk.Label(actions,text='Status').pack(side='left')
            status = tk.StringVar(value='Dropped')
            ttk.Combobox(actions,textvariable=status,values=['Registered','Dropped','Completed'],
                         state='readonly',width=12).pack(side='left',padx=5)
            def update_status():
                def action():
                    self.execute('ChangeRegistrationStatus',(int(reg_id.get()),status.get()),procedure=True)
                    self.refresh(tree,sql)
                self.run(action,'Status updated')
            ttk.Button(actions,text='Update status',command=update_status).pack(side='left',padx=6)
            if self.role == 'registrar':
                ttk.Label(actions,text='Final mark').pack(side='left',padx=6)
                mark = tk.StringVar()
                ttk.Entry(actions,textvariable=mark,width=8).pack(side='left')
                def set_mark():
                    def action():
                        self.execute('SetFinalMark',(int(reg_id.get()),float(mark.get())),procedure=True)
                        self.refresh(tree,sql)
                    self.run(action,'Final mark saved and audited')
                ttk.Button(actions,text='Save mark',command=set_mark).pack(side='left',padx=6)
        self.refresh(tree,sql)

    def reports_tab(self, tab):
        tree = self.query_table(tab)
        options = ttk.Frame(tab,padding=10)
        options.pack(fill='x')
        ttk.Label(options,text='Semester').pack(side='left',padx=4)
        semester = tk.StringVar(value='Fall')
        ttk.Combobox(options,textvariable=semester,values=['Fall','Spring','Summer'],
                     state='readonly',width=12).pack(side='left')
        ttk.Label(options,text='Year').pack(side='left',padx=6)
        year = tk.StringVar(value='2026')
        ttk.Entry(options,textvariable=year,width=9).pack(side='left')
        def load_report():
            try:
                results = self.execute('AcademicSectionReport',(semester.get(),int(year.get())),procedure=True)
                self.display(tree,results)
            except (mysql.connector.Error,ValueError) as exc:
                messagebox.showerror('Report error',str(exc))
        ttk.Button(options,text='Academic performance report',command=load_report).pack(side='left',padx=8)
        ttk.Button(options,text='Registration list',command=lambda:self.refresh(
            tree,'SELECT * FROM RegistrationDetails')).pack(side='left',padx=8)
        ttk.Button(options,text='Section capacity',command=lambda:self.refresh(
            tree,'SELECT * FROM SectionCapacity')).pack(side='left',padx=8)

    def audit_tab(self, tab):
        tree = self.query_table(tab)
        sql='SELECT * FROM RegistrationAudit ORDER BY AuditID DESC'
        ttk.Button(tab,text='Refresh audit history',command=lambda:self.refresh(tree,sql)).pack(
            anchor='e',padx=12,pady=8)
        self.refresh(tree,sql)

if __name__ == '__main__':
    UniversityApp().root.mainloop()