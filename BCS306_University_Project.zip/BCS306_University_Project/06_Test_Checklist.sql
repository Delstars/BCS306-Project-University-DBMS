-- BCS 306 Project 1: SQL tests.
-- Do not run every statement at once. SELECT checks are read-only.
-- Test modifications separately on an isolated copy or when permitted.

USE bcs306_university;

-- Check provided students, instructor and section data
SELECT * FROM Student ORDER BY StudentID;
SELECT * FROM Course ORDER BY CourseCode;
SELECT * FROM Section ORDER BY CourseCode, SectionNo;

-- Derived student age, never stored as a column
SELECT StudentID, FirstName, FamilyName,
       TIMESTAMPDIFF(YEAR, DateOfBirth, CURDATE()) AS Age
FROM Student;

-- Reusable views
SELECT * FROM RegistrationDetails ORDER BY RegistrationID;
SELECT * FROM SectionCapacity ORDER BY CourseCode, SectionNo;

-- Existing audit rows
SELECT * FROM RegistrationAudit ORDER BY AuditID DESC;

-- Advanced Academic Section Performance and Capacity Report
CALL AcademicSectionReport('Fall', 2026);

-- Inspect privileges (run as the MySQL administrator)
-- SHOW GRANTS FOR 'uni_registrar'@'localhost';
-- SHOW GRANTS FOR 'uni_officer'@'localhost';
-- SHOW GRANTS FOR 'uni_report'@'localhost';

-- The following are individual DEMONSTRATIONS, not a batch:
-- Duplicate registration should fail (student 101 already in BCS301 sec 01):
-- CALL RegisterStudent(101,'BCS301','01','Fall',2026);

-- Invalid mark should fail and not change existing data:
-- CALL SetFinalMark(1001,110);

-- Missing mark: marking existing Registered enrollment as Completed must fail:
-- UPDATE Registration SET RegistrationStatus='Completed'
-- WHERE RegistrationID=1002;

-- Section max capacity cannot be less than the current active count.
-- Test after creating sufficient active registrations in a TEST database.

-- Audit demonstration (modifies data): use a separate test database or backup.
-- CALL ChangeRegistrationStatus(1002,'Dropped');
-- SELECT * FROM RegistrationAudit WHERE RegistrationID=1002 ORDER BY AuditID DESC;

-- Officer role test: connect as uni_officer and attempt:
-- CALL SetFinalMark(1001,90);
-- Expected: execute denied for procedure.

-- Report role test: connect as uni_report and attempt:
-- DELETE FROM Registration WHERE RegistrationID=1002;
-- Expected: access denied.

-- Preserve screenshots of each valid and rejected result for the report.
